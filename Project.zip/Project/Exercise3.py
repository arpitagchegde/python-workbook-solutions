from functools import reduce

list_of_lists = [[1,2],[3,4],[5,6]]

flattened_with_reduce = reduce(lambda acc, elem: acc + elem, list_of_lists)

flattened_with_comprehension = [x for sublist in list_of_lists for x in sublist]

maximum_value = max(flattened_with_comprehension)

print("Flattened using reduce:", flattened_with_reduce)
print("Flattened using list comprehension:",flattened_with_comprehension)
print("maximum value:", maximum_value)