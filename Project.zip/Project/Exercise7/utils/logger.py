from datetime import datetime


def log_action(message):
    current_time = datetime.now().strftime("%Y-%m-%d_%H:%M:%S")
    print(f"[{current_time}] {message}")
