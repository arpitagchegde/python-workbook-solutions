import json
from pathlib import Path

def load_config(file_path):
    try:
        with open(file_path, 'r') as file:
            return json.load(file)
    except FileNotFoundError:
        raise FileNotFoundError(f"Error: File '{file_path}' not found")
    except json.JSONDecodeError:
        raise ValueError(f"Error: Failed to decode JSON in '{file_path}' ")
    
def filter_category(config, category):
    if "categories" not in config:
        raise KeyError("Error: 'categories' key not found in configuration")
    if category not in config["categories"]:
        raise KeyError(f"Error: Category '{category}' not found")
    return config["categories"][category]


