import argparse
from utils.config_handler import load_config, filter_category
from utils.logger import log_action

def main():
    parser = argparse.ArgumentParser(description="Filter configuration data by category")
    parser.add_argument(
    "--category",
    type=str,
    required=True,
    help="Category to filter configuaration data"
    )

    args = parser.parse_args()

    config_file_path = "config.json"

    try:
        config_data =load_config(config_file_path)
    except (FileNotFoundError, ValueError) as e:
        print(e)
        return
    

    try:
       filtered_data = filter_category(config_data, args.category)
    except KeyError as e:
        print(e)
        return
    
    print(f"Filtered data for category '{args.category}': {filtered_data}")

    log_action(f"Filtered data for category '{args.category}' ")

if __name__ == "__main__":
    main()
