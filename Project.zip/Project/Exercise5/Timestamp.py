import random
from datetime import datetime
from pathlib import Path

current_datetime = datetime.now()

timestamp = current_datetime.strftime("%Y-%m-%d_%H%M%S")

random_number = random.randint(1000,9999)
filename = f"file_{timestamp}_{random_number}.txt"

output_dir = Path("data_output1")
output_dir.mkdir(exist_ok=True)
file_path = output_dir / filename

content = "Hello, World! This is timestamped file"
with file_path.open(mode ="w") as file:
    file.write(content)

print(f"file '{filename}' has been created with content '{content}' ")