from mypackage.simple_utils import greet
from mypackage.data_utils import add_numbers

if __name__ == "__main__":
    name = "Ram"
    print(greet(name))

    a,b = 2,3
    print(f"The sum of {a} and {b} is {add_numbers(a,b)}")