import json
from pathlib import Path

output_dir = Path("data_output")
output_dir.mkdir(exist_ok=True)

config_data = {
    "debug": True,
    "version": "1.0"
}

config_file = output_dir / "config.json"

with config_file.open(mode ="w") as file:
    json.dump(config_data, file, indent=4)


with config_file.open(mode ="r") as file:
    loaded_data = json.load(file)

print("Config data read from JSON file:", loaded_data)