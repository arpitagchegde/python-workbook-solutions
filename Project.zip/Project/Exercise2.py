from functools import reduce

numbers = [1,2,3,4,5,6]

squared_numbers = list(map(lambda x: x**2, numbers))

odd_squared_numbers = list(filter(lambda x : x%2 != 0 , squared_numbers))

sum_of_odd_squared_numbers = reduce(lambda x, y:x+y, odd_squared_numbers)




print("Squared numbers:", squared_numbers)
print("Odd Squared numbers:", odd_squared_numbers)
print("Sum of Odd Squared numbers:", sum_of_odd_squared_numbers)