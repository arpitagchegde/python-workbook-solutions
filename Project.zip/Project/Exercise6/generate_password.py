import argparse
import random
import string

parser = argparse.ArgumentParser(description="Generate a random password")
parser.add_argument(
    "--length",
    type=int,
    default=8,
    help="Length of the password (default: 8 characters)",

)

args = parser.parse_args()

def generate_password(length):
    characters = string.ascii_letters + string.digits + string.punctuation
    return ''.join(random.choices(characters, k=length))

password = generate_password(args.length)

print(f"Generated password of length {args.length}: {password}")